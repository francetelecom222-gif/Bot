# -*- coding: utf-8 -*-
"""
bot.py
=====================================================================
 Amine Guard Bot — بوت حماية وإدارة مجموعات تيليجرام
 المكتبة: python-telegram-bot (v20+, async)
 قاعدة البيانات: SQLite (عبر database.py)
=====================================================================

طريقة التشغيل:
    1) ثبّت المتطلبات:  pip install -r requirements.txt
    2) عيّن متغير البيئة BOT_TOKEN بتوكن بوتك (لا تكتبه هنا مباشرة).
       على Linux/Mac:  export BOT_TOKEN="xxxxx"
       على Windows:    set BOT_TOKEN=xxxxx
    3) شغّل:  python bot.py

⚠️ تذكير: البوت يجب أن يكون Admin في المجموعة مع صلاحيات:
    - حذف الرسائل (Delete messages)
    - تقييد الأعضاء (Restrict members / Ban users)
"""

import logging
import html
from datetime import datetime, timedelta

from telegram import Update, ChatPermissions, ChatMemberUpdated
from telegram.constants import ParseMode, ChatMemberStatus
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ChatMemberHandler,
    ContextTypes,
    filters as tg_filters,
)
from telegram.error import TelegramError

import config
import database as db
from filters import contains_link, contains_bad_word, is_forwarded, spam_tracker

# ---------------------------------------------------------------------------
# إعداد الـ logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("AmineGuardBot")


# ---------------------------------------------------------------------------
# دوال مساعدة عامة
# ---------------------------------------------------------------------------

async def is_user_admin(chat_id: int, user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    يتحقق إن كان المستخدم مشرفاً أو مالكاً في المجموعة.
    ⚠️ هذا الفحص أساسي لقاعدة: البوت ممنوع يحذف رسائل المشرف/المسؤول.
    """
    try:
        member = await context.bot.get_chat_member(chat_id, user_id)
        return member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)
    except TelegramError as e:
        logger.warning(f"تعذر التحقق من صلاحية الأدمن: {e}")
        return False


def user_display_name(user) -> str:
    if user.username:
        return f"@{user.username}"
    return html.escape(user.full_name or str(user.id))


async def send_to_logs(chat_id: int, text: str, context: ContextTypes.DEFAULT_TYPE):
    """يرسل تقرير المخالفة إلى قناة/مجموعة السجلات إن كانت مُفعّلة."""
    settings = db.get_chat_settings(chat_id)
    logs_chat_id = settings.get("logs_chat_id") or config.DEFAULT_LOGS_CHAT_ID
    if not logs_chat_id:
        return
    try:
        await context.bot.send_message(chat_id=logs_chat_id, text=text, parse_mode=ParseMode.HTML)
    except TelegramError as e:
        logger.warning(f"فشل إرسال السجل: {e}")


async def apply_punishment(update: Update, context: ContextTypes.DEFAULT_TYPE,
                            reason_key: str, message_text: str = ""):
    """
    المسار الموحّد عند اكتشاف مخالفة:
    1) حذف الرسالة
    2) تحديد الإجراء حسب عدد المخالفات التراكمي
    3) تنفيذ الكتم إن لزم (بحد أقصى 10 دقائق)
    4) إرسال رسالة خاصة للمستخدم
    5) إرسال تقرير لسجل الإدارة
    """
    message = update.effective_message
    user = update.effective_user
    chat = update.effective_chat

    # 🔒 قاعدة صلبة: لا تلمس رسائل المشرفين/المالك أبداً
    if await is_user_admin(chat.id, user.id, context):
        return

    reason_label = config.REASON_LABELS.get(reason_key, reason_key)

    # 1) حذف الرسالة
    try:
        await message.delete()
    except TelegramError as e:
        logger.warning(f"تعذر حذف الرسالة: {e}")

    # 2) تحديث عداد المخالفات
    db.ensure_user(chat.id, user.id, user.username, user.full_name)
    count = db.add_violation(
        chat_id=chat.id, user_id=user.id, username=user.username or user.full_name,
        reason=reason_label, action_taken="حذف الرسالة", message_text=message_text,
    )

    # 3) تحديد الإجراء بناءً على العدد التراكمي + نوع المخالفة
    action_desc = "حذف الرسالة"
    mute_seconds = 0

    if count == 1:
        action_desc = "حذف الرسالة + تنبيه"
    elif count == 2:
        action_desc = "حذف الرسالة + تحذير إضافي"
    else:
        # من المخالفة الثالثة: نطبق مدة الكتم الخاصة بنوع المخالفة، لا تتجاوز أبداً 10 دقائق
        base_seconds = config.MUTE_DURATIONS.get(reason_key, 60)
        mute_seconds = min(base_seconds, config.MAX_MUTE_SECONDS)
        action_desc = f"حذف الرسالة + كتم {mute_seconds} ثانية"

    # 4) تنفيذ الكتم إن وُجد
    if mute_seconds > 0:
        until_date = datetime.now() + timedelta(seconds=mute_seconds)
        try:
            await context.bot.restrict_chat_member(
                chat_id=chat.id,
                user_id=user.id,
                permissions=ChatPermissions(can_send_messages=False),
                until_date=until_date,
            )
            db.set_user_muted(chat.id, user.id, until_date.isoformat())
        except TelegramError as e:
            logger.warning(f"تعذر كتم المستخدم: {e}")

    # 5) رسالة خاصة (Whisper) للمستخدم
    try:
        await context.bot.send_message(
            chat_id=user.id,
            text=config.MSG_WARN_PRIVATE.format(reason=reason_label, count=count),
        )
    except TelegramError:
        # المستخدم قد لا يكون بدأ محادثة خاصة مع البوت — هذا متوقع وليس خطأ حرج
        pass

    # 6) تقرير في سجل الإدارة
    log_text = config.MSG_LOG_TEMPLATE.format(
        username=user_display_name(user),
        reason=reason_label,
        action=action_desc,
        count=count,
        time=datetime.now().strftime("%H:%M"),
    )
    await send_to_logs(chat.id, log_text, context)


# ---------------------------------------------------------------------------
# مراقبة الرسائل — الفلترة الرئيسية
# ---------------------------------------------------------------------------

async def monitor_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    if not message or not update.effective_chat or update.effective_chat.type == "private":
        return

    user = update.effective_user
    chat = update.effective_chat
    text = message.text or message.caption or ""

    # 🔒 لا نراقب رسائل المشرفين/المالك إطلاقاً — حرية تامة كما طُلب
    if await is_user_admin(chat.id, user.id, context):
        return

    settings = db.get_chat_settings(chat.id)

    # 1) فحص التوجيه (Forward) الممنوع
    if settings.get("block_forward") and is_forwarded(message):
        await apply_punishment(update, context, "forward", text)
        return

    # 2) فحص الروابط الممنوعة
    if settings.get("block_links") and contains_link(text):
        await apply_punishment(update, context, "link", text)
        return

    # 3) فحص الكلمات البذيئة/السب (القائمة الأساسية + كلمات مخصصة للمجموعة)
    if settings.get("block_bad_words"):
        extra_words = db.get_banned_words(chat.id)
        bad_word = contains_bad_word(text, extra_words)
        if bad_word:
            await apply_punishment(update, context, "bad_word", text)
            return

    # 4) فحص السبام/التكرار
    if settings.get("block_spam"):
        spam_reason = spam_tracker.register_and_check(chat.id, user.id, text)
        if spam_reason:
            await apply_punishment(update, context, "spam", text)
            return


# ---------------------------------------------------------------------------
# نظام الترحيب والمغادرة
# ---------------------------------------------------------------------------

async def on_chat_member_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """يلتقط دخول/خروج الأعضاء عبر ChatMemberHandler (أدق من new_chat_members)."""
    result: ChatMemberUpdated = update.chat_member
    chat = update.effective_chat
    settings = db.get_chat_settings(chat.id)

    old_status = result.old_chat_member.status
    new_status = result.new_chat_member.status
    member_user = result.new_chat_member.user

    joined_statuses = (ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR)
    left_statuses = (ChatMemberStatus.LEFT, ChatMemberStatus.BANNED)

    # === انضمام عضو جديد ===
    if old_status not in joined_statuses and new_status in joined_statuses:
        if not settings.get("welcome_enabled"):
            return
        now = datetime.now()
        db.ensure_user(
            chat.id, member_user.id, member_user.username, member_user.full_name,
            joined_at=now.isoformat(),
        )
        name = html.escape(member_user.full_name or "عضو جديد")
        username = f"@{member_user.username}" if member_user.username else "لا يوجد"
        welcome_text = config.MSG_WELCOME_TEMPLATE.format(
            name=name,
            username=username,
            date=now.strftime("%Y-%m-%d"),
            time=now.strftime("%H:%M"),
        )
        try:
            # صورة ترحيب: يمكن استبدال الرابط بصورة مخصصة مرفوعة لديك (file_id أو مسار محلي)
            await context.bot.send_message(chat_id=chat.id, text=welcome_text)
        except TelegramError as e:
            logger.warning(f"فشل إرسال رسالة الترحيب: {e}")

    # === مغادرة/طرد عضو ===
    elif old_status not in left_statuses and new_status in left_statuses:
        if not settings.get("leave_enabled"):
            return
        username = f"@{member_user.username}" if member_user.username else html.escape(member_user.full_name)
        leave_text = config.MSG_LEAVE_TEMPLATE.format(username=username)
        try:
            await context.bot.send_message(chat_id=chat.id, text=leave_text)
        except TelegramError as e:
            logger.warning(f"فشل إرسال رسالة المغادرة: {e}")


# ---------------------------------------------------------------------------
# أوامر المشرفين
# ---------------------------------------------------------------------------

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 أهلاً بك في Amine Guard Bot!\n"
        "بوت حماية وإدارة المجموعات.\n\n"
        "أضفني كمشرف بصلاحيات (حذف الرسائل + تقييد الأعضاء) في مجموعتك وسأتولى الحماية تلقائياً.\n"
        "استخدم /settings داخل المجموعة لعرض وضبط الإعدادات، و/rules لعرض القوانين."
    )


async def require_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """يتحقق أن مُصدر الأمر هو مشرف، وإلا يرد برسالة رفض. يرجع True إذا مسموح للمتابعة."""
    chat = update.effective_chat
    user = update.effective_user
    if chat.type == "private":
        await update.message.reply_text("هذا الأمر يُستخدم داخل المجموعات فقط.")
        return False
    if not await is_user_admin(chat.id, user.id, context):
        await update.message.reply_text("⛔ هذا الأمر مخصص للمشرفين فقط.")
        return False
    return True


async def cmd_warn(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/warn (رد على رسالة العضو) — يضيف تحذيراً يدوياً من المشرف."""
    if not await require_admin(update, context):
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("استخدم الأمر رداً على رسالة العضو الذي تريد تحذيره.")
        return

    target = update.message.reply_to_message.from_user
    chat = update.effective_chat
    db.ensure_user(chat.id, target.id, target.username, target.full_name)
    count = db.add_violation(
        chat.id, target.id, target.username or target.full_name,
        reason="تحذير يدوي من المشرف", action_taken="تحذير",
    )
    await update.message.reply_text(
        f"⚠️ تم تحذير {user_display_name(target)}. عدد مخالفاته الآن: {count}"
    )
    try:
        await context.bot.send_message(
            chat_id=target.id,
            text=f"⚠️ تلقيت تحذيراً من أحد مشرفي المجموعة. عدد مخالفاتك: {count}",
        )
    except TelegramError:
        pass


async def cmd_mute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/mute [ثواني] (رد على رسالة العضو) — كتم يدوي، بحد أقصى 10 دقائق."""
    if not await require_admin(update, context):
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("استخدم الأمر رداً على رسالة العضو، مثال: /mute 60")
        return

    seconds = 60
    if context.args:
        try:
            seconds = int(context.args[0])
        except ValueError:
            await update.message.reply_text("الرجاء إدخال عدد ثوانٍ صحيح. مثال: /mute 60")
            return

    seconds = min(max(seconds, 1), config.MAX_MUTE_SECONDS)  # لا يتجاوز 10 دقائق أبداً
    target = update.message.reply_to_message.from_user
    chat = update.effective_chat

    if await is_user_admin(chat.id, target.id, context):
        await update.message.reply_text("⛔ لا يمكن كتم مشرف أو المسؤول.")
        return

    until_date = datetime.now() + timedelta(seconds=seconds)
    try:
        await context.bot.restrict_chat_member(
            chat_id=chat.id, user_id=target.id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date,
        )
        db.set_user_muted(chat.id, target.id, until_date.isoformat())
        await update.message.reply_text(f"🔇 تم كتم {user_display_name(target)} لمدة {seconds} ثانية.")
    except TelegramError as e:
        await update.message.reply_text(f"تعذر تنفيذ الكتم: {e}")


async def cmd_unmute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/unmute (رد على رسالة العضو) — إلغاء الكتم فوراً."""
    if not await require_admin(update, context):
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("استخدم الأمر رداً على رسالة العضو.")
        return

    target = update.message.reply_to_message.from_user
    chat = update.effective_chat
    try:
        await context.bot.restrict_chat_member(
            chat_id=chat.id, user_id=target.id,
            permissions=ChatPermissions(
                can_send_messages=True, can_send_photos=True, can_send_videos=True,
                can_send_other_messages=True, can_add_web_page_previews=True,
            ),
        )
        db.set_user_muted(chat.id, target.id, None)
        await update.message.reply_text(f"🔊 تم إلغاء الكتم عن {user_display_name(target)}.")
    except TelegramError as e:
        await update.message.reply_text(f"تعذر إلغاء الكتم: {e}")


async def cmd_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    settings = db.get_chat_settings(chat.id)
    rules = settings.get("rules_text") or "لم يتم تعيين قوانين لهذه المجموعة بعد."
    await update.message.reply_text(f"📜 قوانين المجموعة:\n\n{rules}")


async def cmd_setrules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setrules <النص> — لتحديد نص القوانين (للمشرفين)."""
    if not await require_admin(update, context):
        return
    if not context.args:
        await update.message.reply_text("استخدم: /setrules <نص القوانين>")
        return
    text = " ".join(context.args)
    db.update_chat_setting(update.effective_chat.id, "rules_text", text)
    await update.message.reply_text("✅ تم تحديث قوانين المجموعة.")


async def cmd_addword(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/addword <كلمة> — إضافة كلمة ممنوعة مخصصة للمجموعة."""
    if not await require_admin(update, context):
        return
    if not context.args:
        await update.message.reply_text("استخدم: /addword <الكلمة>")
        return
    word = " ".join(context.args)
    ok = db.add_banned_word(update.effective_chat.id, word)
    if ok:
        await update.message.reply_text(f"✅ تمت إضافة «{word}» لقائمة الكلمات الممنوعة.")
    else:
        await update.message.reply_text("هذه الكلمة موجودة مسبقاً في القائمة.")


async def cmd_removeword(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/removeword <كلمة> — إزالة كلمة من القائمة المخصصة للمجموعة."""
    if not await require_admin(update, context):
        return
    if not context.args:
        await update.message.reply_text("استخدم: /removeword <الكلمة>")
        return
    word = " ".join(context.args)
    ok = db.remove_banned_word(update.effective_chat.id, word)
    if ok:
        await update.message.reply_text(f"✅ تمت إزالة «{word}» من قائمة الكلمات الممنوعة.")
    else:
        await update.message.reply_text("هذه الكلمة غير موجودة في القائمة المخصصة (قد تكون من القائمة الأساسية بالكود).")


async def cmd_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/logs — يعرض آخر المخالفات المسجلة في هذه المجموعة."""
    if not await require_admin(update, context):
        return
    violations = db.get_recent_violations(update.effective_chat.id, limit=15)
    if not violations:
        await update.message.reply_text("لا توجد مخالفات مسجلة بعد.")
        return
    lines = ["🗂️ آخر المخالفات المسجلة:\n"]
    for v in violations:
        lines.append(
            f"• {v['username'] or v['user_id']} — {v['reason']} ({v['action_taken']}) — {v['created_at'][:16]}"
        )
    await update.message.reply_text("\n".join(lines))


async def cmd_setlogschat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setlogschat — يُستخدم داخل قناة/مجموعة السجلات لربطها بهذه المجموعة (أرسل الأمر مع معرف المجموعة)."""
    if not await require_admin(update, context):
        return
    if not context.args:
        await update.message.reply_text(
            "استخدم: /setlogschat <chat_id للسجلات>\n"
            "أضف البوت لقناة/مجموعة السجلات كمشرف، واحصل على معرفها ثم نفّذ الأمر هنا."
        )
        return
    try:
        logs_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("معرف غير صالح.")
        return
    db.update_chat_setting(update.effective_chat.id, "logs_chat_id", logs_id)
    await update.message.reply_text("✅ تم تعيين وجهة السجلات لهذه المجموعة.")


# --- لوحة الإعدادات (/settings) -------------------------------------------

SETTINGS_KEYS_AR = {
    "block_links": "منع الروابط",
    "block_bad_words": "منع الكلمات البذيئة",
    "block_forward": "منع التوجيه (Forward)",
    "block_spam": "منع السبام",
    "welcome_enabled": "رسائل الترحيب",
    "leave_enabled": "رسائل المغادرة",
    "autopost_enabled": "النشر التلقائي",
}


async def cmd_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /settings           -> يعرض الإعدادات الحالية
    /settings <key> on|off -> يشغّل/يوقف إعداداً معيناً
    مثال: /settings block_links off
    """
    if not await require_admin(update, context):
        return

    chat = update.effective_chat
    settings = db.get_chat_settings(chat.id)

    if not context.args:
        lines = ["⚙️ إعدادات المجموعة الحالية:\n"]
        for key, label in SETTINGS_KEYS_AR.items():
            status = "✅ مفعّل" if settings.get(key) else "❌ متوقف"
            lines.append(f"• {label} ({key}): {status}")
        lines.append(
            "\nللتغيير: /settings <المفتاح> on|off\n"
            "مثال: /settings block_links off"
        )
        await update.message.reply_text("\n".join(lines))
        return

    if len(context.args) < 2:
        await update.message.reply_text("الصيغة: /settings <المفتاح> on|off")
        return

    key, value = context.args[0], context.args[1].lower()
    if key not in SETTINGS_KEYS_AR:
        await update.message.reply_text(f"مفتاح غير معروف. الخيارات المتاحة: {', '.join(SETTINGS_KEYS_AR)}")
        return
    if value not in ("on", "off"):
        await update.message.reply_text("استخدم on أو off فقط.")
        return

    db.update_chat_setting(chat.id, key, 1 if value == "on" else 0)
    await update.message.reply_text(f"✅ تم تحديث «{SETTINGS_KEYS_AR[key]}» إلى {'مفعّل' if value=='on' else 'متوقف'}.")


# --- النشر التلقائي ---------------------------------------------------------

async def cmd_addpost(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /addpost HH:MM <النص> — يضيف منشوراً مجدولاً يومياً في وقت محدد.
    يتطلب تفعيل autopost_enabled عبر /settings autopost_enabled on
    ويتطلب تشغيل الـ JobQueue (مُفعّل تلقائياً في main()).
    """
    if not await require_admin(update, context):
        return
    if len(context.args) < 2:
        await update.message.reply_text("استخدم: /addpost HH:MM النص هنا")
        return

    time_str = context.args[0]
    text = " ".join(context.args[1:])
    try:
        hour, minute = map(int, time_str.split(":"))
        assert 0 <= hour <= 23 and 0 <= minute <= 59
    except (ValueError, AssertionError):
        await update.message.reply_text("صيغة الوقت غير صحيحة. استخدم HH:MM مثل 18:30")
        return

    chat_id = update.effective_chat.id
    post_id = db.add_scheduled_post(chat_id, text, hour, minute)

    # جدولة الوظيفة اليومية عبر JobQueue
    context.job_queue.run_daily(
        callback=send_scheduled_post,
        time=__import__("datetime").time(hour=hour, minute=minute),
        chat_id=chat_id,
        name=f"post_{post_id}",
        data={"chat_id": chat_id, "text": text},
    )

    await update.message.reply_text(f"✅ تمت جدولة النشر يومياً الساعة {time_str}.")


async def send_scheduled_post(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    settings = db.get_chat_settings(job.data["chat_id"])
    if not settings.get("autopost_enabled"):
        return
    try:
        await context.bot.send_message(chat_id=job.data["chat_id"], text=job.data["text"])
    except TelegramError as e:
        logger.warning(f"فشل النشر المجدول: {e}")


def reschedule_all_posts(application: Application):
    """يُعاد جدولة كل المنشورات المحفوظة عند إعادة تشغيل البوت (لأن JobQueue بالذاكرة فقط)."""
    import datetime as dt
    posts = db.get_scheduled_posts()
    for post in posts:
        application.job_queue.run_daily(
            callback=send_scheduled_post,
            time=dt.time(hour=post["hour"], minute=post["minute"]),
            chat_id=post["chat_id"],
            name=f"post_{post['id']}",
            data={"chat_id": post["chat_id"], "text": post["text"]},
        )
    if posts:
        logger.info(f"تمت إعادة جدولة {len(posts)} منشور تلقائي.")


# ---------------------------------------------------------------------------
# نقطة التشغيل الرئيسية
# ---------------------------------------------------------------------------

def main():
    if not config.BOT_TOKEN or "ضع_التوكن" in config.BOT_TOKEN:
        raise SystemExit(
            "❌ لم يتم تعيين التوكن. عيّن متغير البيئة BOT_TOKEN قبل التشغيل.\n"
            "مثال: export BOT_TOKEN='xxxxxxxxx'"
        )

    db.init_db()

    application = ApplicationBuilder().token(config.BOT_TOKEN).build()

    # أوامر أساسية
    application.add_handler(CommandHandler("start", cmd_start))
    application.add_handler(CommandHandler("warn", cmd_warn))
    application.add_handler(CommandHandler("mute", cmd_mute))
    application.add_handler(CommandHandler("unmute", cmd_unmute))
    application.add_handler(CommandHandler("rules", cmd_rules))
    application.add_handler(CommandHandler("setrules", cmd_setrules))
    application.add_handler(CommandHandler("addword", cmd_addword))
    application.add_handler(CommandHandler("removeword", cmd_removeword))
    application.add_handler(CommandHandler("logs", cmd_logs))
    application.add_handler(CommandHandler("setlogschat", cmd_setlogschat))
    application.add_handler(CommandHandler("settings", cmd_settings))
    application.add_handler(CommandHandler("addpost", cmd_addpost))

    # مراقبة الرسائل النصية/الكابشن (غير الأوامر)
    application.add_handler(
        MessageHandler(tg_filters.TEXT & ~tg_filters.COMMAND, monitor_messages)
    )
    application.add_handler(
        MessageHandler(tg_filters.CAPTION, monitor_messages)
    )

    # تتبع دخول/خروج الأعضاء (أدق طريقة في PTB v20+)
    application.add_handler(
        ChatMemberHandler(on_chat_member_update, ChatMemberHandler.CHAT_MEMBER)
    )

    # إعادة جدولة المنشورات التلقائية المحفوظة سابقاً
    reschedule_all_posts(application)

    logger.info("🚀 Amine Guard Bot يعمل الآن...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
