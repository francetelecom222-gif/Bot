# -*- coding: utf-8 -*-
"""
database.py
طبقة قاعدة البيانات لـ Amine Guard Bot
تستخدم SQLite (ملف db.sqlite3 داخل مجلد data/)
"""

import sqlite3
import json
import os
from datetime import datetime
from contextlib import contextmanager

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "db.sqlite3")


def _row_to_dict(cursor, row):
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


@contextmanager
def get_conn():
    """يفتح اتصال آمن بقاعدة البيانات ويغلقه تلقائياً."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """ينشئ الجداول إذا لم تكن موجودة. يُستدعى مرة عند بدء تشغيل البوت."""
    with get_conn() as conn:
        cur = conn.cursor()

        # جدول المستخدمين لكل مجموعة (عدّاد المخالفات لكل مستخدم داخل كل مجموعة)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            chat_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            username TEXT,
            full_name TEXT,
            violations_count INTEGER DEFAULT 0,
            is_muted INTEGER DEFAULT 0,
            muted_until TEXT,
            joined_at TEXT,
            PRIMARY KEY (chat_id, user_id)
        )
        """)

        # جدول سجل المخالفات (تاريخي، لكل مخالفة سطر مستقل)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS violations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            username TEXT,
            reason TEXT NOT NULL,
            action_taken TEXT NOT NULL,
            message_text TEXT,
            created_at TEXT NOT NULL
        )
        """)

        # إعدادات كل مجموعة (تشغيل/إيقاف كل ميزة)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS chat_settings (
            chat_id INTEGER PRIMARY KEY,
            block_links INTEGER DEFAULT 1,
            block_bad_words INTEGER DEFAULT 1,
            block_forward INTEGER DEFAULT 1,
            block_spam INTEGER DEFAULT 1,
            welcome_enabled INTEGER DEFAULT 1,
            leave_enabled INTEGER DEFAULT 1,
            autopost_enabled INTEGER DEFAULT 0,
            logs_chat_id INTEGER,
            rules_text TEXT DEFAULT ''
        )
        """)

        # الكلمات الممنوعة المخصصة لكل مجموعة (بالإضافة للقائمة الأساسية بالكود)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS banned_words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            word TEXT NOT NULL,
            UNIQUE(chat_id, word)
        )
        """)

        # رسائل النشر التلقائي المجدولة
        cur.execute("""
        CREATE TABLE IF NOT EXISTS scheduled_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            hour INTEGER NOT NULL,
            minute INTEGER NOT NULL,
            active INTEGER DEFAULT 1
        )
        """)

        # جدول مؤقت لتتبع الرسائل المتكررة (سبام) - سجل بسيط بالذاكرة يُفضّل،
        # لكن نضيف هنا سجل احتياطي بسيط قابل للاستخدام إن لزم
        cur.execute("""
        CREATE TABLE IF NOT EXISTS message_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            text_hash TEXT,
            created_at TEXT NOT NULL
        )
        """)


# ---------------------------------------------------------------------------
# دوال إعدادات المجموعة
# ---------------------------------------------------------------------------

DEFAULT_SETTINGS = {
    "block_links": 1,
    "block_bad_words": 1,
    "block_forward": 1,
    "block_spam": 1,
    "welcome_enabled": 1,
    "leave_enabled": 1,
    "autopost_enabled": 0,
    "logs_chat_id": None,
    "rules_text": "",
}


def get_chat_settings(chat_id: int) -> dict:
    """يرجع إعدادات المجموعة، وينشئ سطراً افتراضياً إذا لم يكن موجوداً."""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM chat_settings WHERE chat_id = ?", (chat_id,))
        row = cur.fetchone()
        if row is None:
            cur.execute(
                "INSERT INTO chat_settings (chat_id) VALUES (?)", (chat_id,)
            )
            conn.commit()
            return dict(DEFAULT_SETTINGS, chat_id=chat_id)
        return dict(row)


def update_chat_setting(chat_id: int, key: str, value):
    """يحدّث حقلاً واحداً في إعدادات المجموعة."""
    allowed_keys = {
        "block_links", "block_bad_words", "block_forward", "block_spam",
        "welcome_enabled", "leave_enabled", "autopost_enabled",
        "logs_chat_id", "rules_text",
    }
    if key not in allowed_keys:
        raise ValueError(f"إعداد غير معروف: {key}")

    get_chat_settings(chat_id)  # التأكد من وجود السطر
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"UPDATE chat_settings SET {key} = ? WHERE chat_id = ?", (value, chat_id))


def toggle_chat_setting(chat_id: int, key: str) -> int:
    """يعكس قيمة إعداد (0/1) ويرجع القيمة الجديدة."""
    settings = get_chat_settings(chat_id)
    new_value = 0 if settings.get(key) else 1
    update_chat_setting(chat_id, key, new_value)
    return new_value


# ---------------------------------------------------------------------------
# دوال المستخدمين والمخالفات
# ---------------------------------------------------------------------------

def ensure_user(chat_id: int, user_id: int, username: str, full_name: str, joined_at: str = None):
    """يضمن وجود سجل للمستخدم في هذه المجموعة."""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM users WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        if cur.fetchone() is None:
            cur.execute("""
                INSERT INTO users (chat_id, user_id, username, full_name, joined_at)
                VALUES (?, ?, ?, ?, ?)
            """, (chat_id, user_id, username, full_name, joined_at or datetime.now().isoformat()))
        else:
            cur.execute("""
                UPDATE users SET username=?, full_name=? WHERE chat_id=? AND user_id=?
            """, (username, full_name, chat_id, user_id))


def get_user(chat_id: int, user_id: int) -> dict | None:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        row = cur.fetchone()
        return dict(row) if row else None


def add_violation(chat_id: int, user_id: int, username: str, reason: str,
                   action_taken: str, message_text: str = "") -> int:
    """
    يسجل مخالفة جديدة، يزيد عداد المستخدم، ويرجع العدد الجديد للمخالفات.
    """
    with get_conn() as conn:
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO violations (chat_id, user_id, username, reason, action_taken, message_text, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (chat_id, user_id, username, reason, action_taken, message_text[:500], datetime.now().isoformat()))

        cur.execute("SELECT violations_count FROM users WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        row = cur.fetchone()
        if row is None:
            cur.execute("""
                INSERT INTO users (chat_id, user_id, username, violations_count, joined_at)
                VALUES (?, ?, ?, 1, ?)
            """, (chat_id, user_id, username, datetime.now().isoformat()))
            return 1
        else:
            new_count = row["violations_count"] + 1
            cur.execute("""
                UPDATE users SET violations_count=?, username=? WHERE chat_id=? AND user_id=?
            """, (new_count, username, chat_id, user_id))
            return new_count


def reset_violations(chat_id: int, user_id: int):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET violations_count=0 WHERE chat_id=? AND user_id=?", (chat_id, user_id))


def set_user_muted(chat_id: int, user_id: int, muted_until_iso: str | None):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            UPDATE users SET is_muted=?, muted_until=? WHERE chat_id=? AND user_id=?
        """, (1 if muted_until_iso else 0, muted_until_iso, chat_id, user_id))


def get_recent_violations(chat_id: int, limit: int = 20) -> list:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM violations WHERE chat_id=? ORDER BY id DESC LIMIT ?
        """, (chat_id, limit))
        return [dict(r) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# دوال الكلمات الممنوعة المخصصة
# ---------------------------------------------------------------------------

def add_banned_word(chat_id: int, word: str) -> bool:
    word = word.strip().lower()
    if not word:
        return False
    with get_conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO banned_words (chat_id, word) VALUES (?, ?)", (chat_id, word))
            return True
        except sqlite3.IntegrityError:
            return False


def remove_banned_word(chat_id: int, word: str) -> bool:
    word = word.strip().lower()
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM banned_words WHERE chat_id=? AND word=?", (chat_id, word))
        return cur.rowcount > 0


def get_banned_words(chat_id: int) -> list:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT word FROM banned_words WHERE chat_id=?", (chat_id,))
        return [r["word"] for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# دوال النشر التلقائي
# ---------------------------------------------------------------------------

def add_scheduled_post(chat_id: int, text: str, hour: int, minute: int) -> int:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO scheduled_posts (chat_id, text, hour, minute, active)
            VALUES (?, ?, ?, ?, 1)
        """, (chat_id, text, hour, minute))
        return cur.lastrowid


def get_scheduled_posts(chat_id: int = None) -> list:
    with get_conn() as conn:
        cur = conn.cursor()
        if chat_id:
            cur.execute("SELECT * FROM scheduled_posts WHERE chat_id=? AND active=1", (chat_id,))
        else:
            cur.execute("SELECT * FROM scheduled_posts WHERE active=1")
        return [dict(r) for r in cur.fetchall()]


def deactivate_scheduled_post(post_id: int):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE scheduled_posts SET active=0 WHERE id=?", (post_id,))
