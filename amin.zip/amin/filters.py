# -*- coding: utf-8 -*-
"""
filters.py
منطق الكشف عن المخالفات: روابط ممنوعة، كلمات بذيئة (عربي/إنجليزي/فرنسي)،
سبام (تكرار رسائل)، وتوجيه (forward).

ملاحظة مهمة: القوائم أدناه أساسية/عامة فقط للانطلاق.
يُنصح بشدة بتوسيعها عبر أوامر /addword داخل كل مجموعة حسب الحاجة،
لأن أي قائمة ثابتة بالكود لن تكون شاملة أبداً.
"""

import re
import time
from collections import defaultdict, deque

# -----------------------------------------------------------------------
# 1) قائمة أساسية للكلمات البذيئة / السب (عربي + إنجليزي + فرنسي)
#    هذه قائمة "بذور" (seed list) بسيطة ومهذبة الصياغة هنا لأغراض العرض،
#    يُفترض أن تستبدلها/توسّعها بقائمة أشمل تناسب مجتمعك عبر /addword.
# -----------------------------------------------------------------------
BASE_BAD_WORDS = {
    # عربي - أمثلة عامة لكلمات سب شائعة (صياغة مخفّفة كبذور فقط)
    "كلب", "حمار", "غبي", "احمق", "خرا", "قحبة", "شرموطة", "منيك",
    "كسمك", "زبي", "عرص", "خول", "ابن الكلب", "ابن كلب", "لعنة",

    # إنجليزي - كلمات شائعة (بذور فقط)
    "fuck", "shit", "bitch", "asshole", "bastard", "dick", "pussy",
    "cunt", "slut", "whore", "nigger", "faggot",

    # فرنسي - كلمات شائعة (بذور فقط)
    "putain", "merde", "connard", "salope", "encule", "pute",
}

# -----------------------------------------------------------------------
# 2) أنماط الروابط الممنوعة
# -----------------------------------------------------------------------
URL_PATTERN = re.compile(
    r'(https?://\S+|www\.\S+|t\.me/\S+|telegram\.me/\S+|\S+\.(com|net|org|io|xyz|info|biz|me|tv|ru|top|click|link)\b)',
    re.IGNORECASE
)

# دومينات مسموحة (whitelist) يمكن للمشرف تعديلها لاحقاً عبر قاعدة البيانات إن رغب
DEFAULT_WHITELIST_DOMAINS = set()


def normalize_text(text: str) -> str:
    """يبسّط النص لتفادي الالتفاف عبر رموز/تباعد/تشكيل."""
    if not text:
        return ""
    text = text.lower()
    # إزالة التشكيل العربي
    text = re.sub(r'[\u064B-\u0652]', '', text)
    # استبدال الأرقام الشائعة كبدائل حروف (leetspeak خفيف)
    leet_map = {'0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '@': 'a', '$': 's'}
    for k, v in leet_map.items():
        text = text.replace(k, v)
    # إزالة الفواصل المتكررة بين الحروف مثل ف.ك أو f-u-c-k
    text = re.sub(r'[\.\-_*]+', '', text)
    # إزالة المسافات الزائدة
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def contains_link(text: str) -> bool:
    if not text:
        return False
    return bool(URL_PATTERN.search(text))


def contains_bad_word(text: str, extra_words: set | list = None) -> str | None:
    """
    يرجع الكلمة المخالفة إن وُجدت، وإلا None.
    extra_words: كلمات إضافية خاصة بالمجموعة (من قاعدة البيانات).
    """
    if not text:
        return None
    normalized = normalize_text(text)
    all_words = set(BASE_BAD_WORDS)
    if extra_words:
        all_words |= {normalize_text(w) for w in extra_words}

    for word in all_words:
        if not word:
            continue
        # مطابقة على مستوى الكلمة أو كجزء ملاصق (يغطي أغلب المحاولات البسيطة للتحايل)
        if word in normalized:
            return word
    return None


def is_forwarded(message) -> bool:
    """يفحص إن كانت الرسالة معاد توجيهها (متوافق مع نسخ PTB الحديثة والقديمة)."""
    return bool(
        getattr(message, "forward_origin", None) or
        getattr(message, "forward_from", None) or
        getattr(message, "forward_from_chat", None) or
        getattr(message, "forward_date", None)
    )


# -----------------------------------------------------------------------
# 3) كاشف السبام / تكرار الرسائل (بالذاكرة، لكل chat+user)
# -----------------------------------------------------------------------
class SpamTracker:
    """
    يتتبع آخر رسائل كل مستخدم في كل مجموعة خلال نافذة زمنية قصيرة
    لاكتشاف: (أ) الإرسال المتكرر السريع (flood)، (ب) تكرار نفس النص.
    """

    def __init__(self, window_seconds: int = 8, max_messages: int = 5, repeat_threshold: int = 3):
        self.window_seconds = window_seconds
        self.max_messages = max_messages          # عدد رسائل يعتبر "فيضان"
        self.repeat_threshold = repeat_threshold   # عدد تكرار نفس النص يعتبر سبام
        self._history = defaultdict(lambda: deque())  # key=(chat_id,user_id) -> deque[(ts, text)]

    def register_and_check(self, chat_id: int, user_id: int, text: str) -> str | None:
        """
        يسجل الرسالة الحالية ويرجع سبب السبام إن وُجد ("flood" أو "repeat")، وإلا None.
        """
        key = (chat_id, user_id)
        now = time.time()
        history = self._history[key]
        history.append((now, text or ""))

        # إزالة الرسائل القديمة خارج النافذة الزمنية
        while history and now - history[0][0] > self.window_seconds:
            history.popleft()

        # (أ) فحص الفيضان: عدد رسائل كبير خلال نافذة قصيرة
        if len(history) >= self.max_messages:
            return "flood"

        # (ب) فحص التكرار: نفس النص يتكرر عدة مرات
        if text:
            same_text_count = sum(1 for _, t in history if t.strip() == text.strip())
            if same_text_count >= self.repeat_threshold:
                return "repeat"

        return None

    def clear(self, chat_id: int, user_id: int):
        self._history.pop((chat_id, user_id), None)


# مثيل عام واحد يُستخدم عبر كل البوت
spam_tracker = SpamTracker()
